import java.util.Scanner;
import java.math.*;
public class Bisec2 {
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
    int n;
    double x=1;
    double a=1,b=2,flag1=0,flag2=0;
    double mid=0;
    double acc=0.001;
    System.out.println("Please enter no of terms :"); n=in.nextInt();
     double val[]=new double[n];
     double power[]=new double[n];
    for(int i=0;i<n;i++)
    {
        System.out.println("Enter "+(i+1)+" coefficient :");  val[i]=in.nextDouble(); System.out.println("Enter "+(i+1)+" power :"); power[i]=in.nextDouble();
    }
  // For a and b 
    double fun=0; x=a;
    for(int i=0;i<n;i++)
    {
        fun=fun+val[i]*Math.pow(x, power[i]);
    }
    flag1=fun;
    
    fun=0; x=b;
    for(int i=0;i<n;i++)
    {
        fun=fun+val[i]*Math.pow(x, power[i]);
    }    
    flag2=fun;
    
    fun=0;
    for(int i=0;i<n;i++)
    {
        fun=fun+val[i]*Math.pow(x, power[i]);
    }
    mid=(a+b)/2;   
    x=mid;
    fun=0;
    for(int i=0;i<n;i++)
    {
        fun=fun+val[i]*Math.pow(x, power[i]);
    }
    while(Math.abs(fun)>0.001)
    {
   if(flag1>0)
   {
      
      if(fun<0)
    {
    b=x;
    }
    else
    {
    a=x;
    }
    mid=(a+b)/2;   
     x=mid;
    fun=0;
    for(int i=0;i<n;i++)
    {
        fun=fun+val[i]*Math.pow(x, power[i]);
    }   
       
   }
   else
   {
       
         if(fun>0)
    {
    b=x;
    }
    else
    {
    a=x;
    }
    mid=(a+b)/2;   
     x=mid;
    fun=0;
    for(int i=0;i<n;i++)
    {
        fun=fun+val[i]*Math.pow(x, power[i]);
    }
       
   }
  
    }
   
   System.out.println(x);
    
    
    
    }
    
}
