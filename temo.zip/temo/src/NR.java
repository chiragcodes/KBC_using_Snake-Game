/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dell
 */

import java.util.Scanner;
import java.math.*;

/*public class NR {
public static void main(String args[])
{
    Scanner in=new Scanner(System.in);
    System.out.println("Enter the root :");
    float root=in.nextFloat();1
-5
1

    float f,f1,f2,x=0,temp;
    x=root;
    f=x*x*x-5*x+1;
    f1=3*x*x-5;
    f2=6*x;
    
    while((Math.abs(f*f2))>=(f1*f1))
    {
    System.out.println("Enter the root :");
    root=in.nextFloat();
    x=root;
    f=x*x*x-5*x+1;
    f1=3*x*x-5;
    f2=6*x;
    }
    
    temp=x;
    
    
    
    
    
}
}*/

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//package javaapplication7;
//import java.util.Scanner;
//import java.math.*;
/**
 *
 * @author iis
 */
public class NR {
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        float x=0,f,f1,f2,temp;
        System.out.println("Please enter the coefficients :\n");
   System.out.println("Coefficient of x3"); int a1 =in.nextInt();
   System.out.println("Coefficient of x1");int b1 =in.nextInt();
   System.out.println("Coefficient of x0");int c1 =in.nextInt();
   System.out.println("Please enter the root :"); float root=in.nextFloat();
   x=root;
   f=x*x*x*a1+x*b1+c1;
   f1=3*x*x*a1+b1;
   f2=6*x*a1;
  
   while((Math.abs(f*f2))>=(f1*f1))
   {
       System.out.println(Math.abs(f*f2));
          System.out.println(f1*f1);
             System.out.println(x);
   System.out.println("Please enter the root :"); root=in.nextFloat();
   x=root;  
     f=x*x*x*a1+x*b1+c1;
   f1=3*x*x*a1+b1;
   f2=6*x*a1;
   }
   
   temp=x-(f/f1);
   x=temp;
   while(Math.abs(f)>0.001)
   {
       
   f=x*x*x*a1+x*b1+c1;
   f1=3*x*x*a1+b1;
   f2=6*x*a1; 
   temp=x-(f/f1);
   x=temp;
  
   }
    
   System.out.println("The value is : "+x);
     
    }
}
