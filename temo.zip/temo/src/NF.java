import java.util.Scanner;


public class NF {
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        float x[]=new float[5];        
        float y[][]=new float[5][5];
        
        for(int i=0;i<5;i++)
        {
            System.out.println(" Enter x"+(i+1)+"\t");
            x[i]=in.nextFloat();
            System.out.println(" Enter y"+(i+1)+"\t");
            y[0][i]=in.nextFloat();
            
        }
        System.out.println("\n\n\n");
 /*       for(int i=0;i<5;i++)
        {
            System.out.println("x"+(i+1)+"\t"+(x[i]));
            
            System.out.println(" y"+(i+1)+"\t"+(y[i][0]));
         
            
        }*/
 
        for(int i=1;i<5;i++)
        {
         for(int j=0;j<5-i;j++)
         {
             y[i][j]=y[i-1][j+1]-y[i-1][j];
         }
        } 
        System.out.println("\n\n");
        
          for(int i=0;i<5;i++)
         {
         for(int j=0;j<5-i;j++)
         {
             System.out.print("\t"+y[j][i]);
             
         }
         System.out.println("\n");
         }
        
        
        System.out.println("\n\nPlease enter the value of x :\t");
        float find=in.nextFloat();
        float p=(find-50)/10;
                
      
        float ans=y[0][0]+y[1][0]*p+y[2][0]*p*(p-1)/2+p*(p-1)*(p-2)*y[3][0]/6+p*(p-1)*(p-2)*(p-3)*y[4][0]/24;
        System.out.println("\n\nAnswer is "+ans);
        
        
                
        System.out.println(y[4][0]);
  
  
  
    }
        
    }
    
