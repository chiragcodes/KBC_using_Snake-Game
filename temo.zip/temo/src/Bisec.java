
import java.util.Scanner;
import java.math.*;
public class Bisec {
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
    System.out.println("hello");
    float x=1;
    float a=0,b=1;
    float mid=0;
    float acc=(float) 0.001;
   System.out.println("Please enter the coefficients :\n");
   System.out.println("Coefficient of x3"); int a1 =in.nextInt();
   System.out.println("Coefficient of x1");int b1 =in.nextInt();
   System.out.println("Coefficient of x0");int c1 =in.nextInt();
   float fun=x*x*x*a1+x*b1+c1;
  //System.out.println(fun);
    mid=(a+b)/2;   
    x=mid;
    fun=x*x*x*a1+x*b1+c1;
    while(Math.abs(fun)>0.001)
    {
   
    if(fun<0)
    {
    b=x;
    }
    else
    {
    a=x;
    }
    mid=(a+b)/2;   
     x=mid;
    fun=x*x*x*a1+x*b1+c1;
    }
   
   System.out.println(x);
    
    
    
    }
    
}
