/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dell
 */

import java.util.Scanner;
import java.math.*;
public class False {
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
    System.out.println("hello");
    float x=1;
    float a=0,b=1,temp1=0,temp2=0;
    
    float mid=0;
    float acc=(float) 0.001;
    System.out.println("Please enter the intervals :\n");
    System.out.println("Enter a :");
       a=in.nextFloat();
    System.out.println("Enter b :"); 
    b=in.nextFloat();
   System.out.println("Please enter the coefficients :\n");
   System.out.println("Coefficient of x3"); int a1 =in.nextInt();
   System.out.println("Coefficient of x1");int b1 =in.nextInt();
   System.out.println("Coefficient of x0");int c1 =in.nextInt();
   x=a;
   float fun=x*x*x*a1+x*b1+c1;
   temp1=fun;
   x=b;
   fun=x*x*x*a1+x*b1+c1;
   temp2=fun;
  //System.out.println(fun);
   // mid=(a+b)/2;
   mid=(a*temp2-b*temp1)/(temp2-temp1);
    x=mid;
    fun=x*x*x*a1+x*b1+c1;
    while(Math.abs(fun)>0.001)
    {
   
    if(fun<0)
    {
    b=x;
    temp2=b*b*b*a1+b*b1+c1;
    }
    else
    {
    a=x;
    temp1=a*a*a*a1+a*b1+c1;
    }
    
    
   // mid=(a+b)/2;   
     mid=(a*temp2-b*temp1)/(temp2-temp1);
     x=mid;
    fun=x*x*x*a1+x*b1+c1;
    }
   
   System.out.println(x);
    
    
    
    }
    
}
