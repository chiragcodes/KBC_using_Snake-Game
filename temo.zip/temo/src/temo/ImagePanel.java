/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temo;

/**
 *
 * @author Dell
 */
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;

public class ImagePanel extends JApplet implements KeyListener{
	
	JLabel image1;
	JPanel p1;
         Graphics2D  g2D;
        MY_Thread thr=new MY_Thread();
        
         private final int LEFT = 37;
    private final int RIGHT = 39;
    private final int UP = 38;
    private final int DOWN = 40;
    int direction =2;
    int px[]={300,320,340,360,380};
    int py[]={500,500,500,500,500};
    int hx=300;
    int hy=500;
    int lev=0;
    int flag=0;
    int given=0;
    int money=0;
    int stop=0;
    int top1=0;
    int top2=0;
     int top3=0;
     int top4=0;
     int count=30;
     String cout;
     String q=new String();
    String opta=new String();
    String optb=new String();
    String optc=new String();
    String optd=new String();
    char arrq[];
    char arropta[];
    char arroptb[];
    char arroptc[];
    char arroptd[];
    char ans;
   

	//Container c1=getContentPane();
	public void init()
	{
            
  		setSize(1355,680);
                Container c1=getContentPane();
      //  cpane.add(snakePanel);
         image1=new JLabel();
                image1.setIcon(new ImageIcon("C:\\Users\\Dell\\Desktop\\a.jpg"));
                image1.setBounds(1160, 8, 200, 200);
                p1=new JPanel();
		p1.setPreferredSize(new Dimension(80,50));
                add(image1);
                c1.add(p1);
                thr.start();
                repaint();
    	}
        
        
        public void level()
        {
            Q ob=new Q();
        q=ob.getq(lev);
        arrq=q.toCharArray();
        opta=ob.getopa(lev);
         int len1=(24-opta.length())/2;
         String temp1="";
        for(int i=0;i<len1;i++)
        {
        temp1=temp1+" ";
        }
        opta=temp1+opta;
        arropta=opta.toCharArray();
     
        optb=ob.getopb(lev);
        int len2=(24-optb.length())/2;
         String temp2="";
        for(int i=0;i<len2;i++)
        {
        temp2=temp2+" ";
        }
        optb=temp2+optb;
        arroptb=optb.toCharArray();
        
        optc=ob.getopc(lev);
        int len3=(24-optc.length())/2;
         String temp3="";
        for(int i=0;i<len3;i++)
        {
        temp3=temp3+" ";
        }
        optc=temp3+optc;
        arroptc=optc.toCharArray();
        
        optd=ob.getopd(lev);
        int len4=(24-optd.length())/2;
         String temp4="";
        for(int i=0;i<len4;i++)
        {
        temp4=temp4+" ";
        }
        optd=temp4+optd;
        arroptd=optd.toCharArray();
        
        ans=ob.getan(lev);
        }
        
	
	public void paint(Graphics g)
	{
      		super.paint(g);
               //  Graphics2D  g2D=(Graphics2D)g;
               g2D=(Graphics2D)g;
        g2D.setColor(Color.BLACK);
        //                   g2D.fillRect(0, 0, 1355, 780);
      //  g2D.setColor(Color.gray);
        g2D.fillRect(0, 0,1160, 730);
        g2D.fillRect(0, 183,1355, 513);
        g2D.fillRect(0, 0,1355,32);
        g2D.fillRect(1310, 0,55, 513);
        g2D.setColor(Color.green);
        g2D.drawRect(3, 5, 1342, 418);
        g2D.drawRect(4, 6, 1340, 416);
        g2D.drawRect(7, 9, 1334, 410);
        g2D.drawRect(8, 10, 1332, 408);
        g2D.drawRect(3, 421, 1342, 257);
        g2D.drawRect(4, 422, 1340, 255);
        g2D.drawRect(7, 425, 1334, 249);
        g2D.drawRect(8, 426, 1332, 247);
         g2D.setColor(Color.black);
        g2D.fillRect(5, 422, 1336, 6);
     
         if(given==1 && ((lev!=0) && (lev!=4) && (lev!=8)))
{ thr.stop();
count=0;
//JOptionPane.showConfirmDialog(null, "Are you sure you want to quit!");   // For quit
JOptionPane.showConfirmDialog(null,"Your winning amount :  "+Integer.toString(money),"Sorry you lose",JOptionPane.DEFAULT_OPTION);
Sorry s=new Sorry();
s.setVisible(true);
}
else if(given==2 && ((lev!=1) && (lev!=5) && (lev!=9)))
{thr.stop();
count=0;
JOptionPane.showConfirmDialog(null,"Your winning amount :  "+Integer.toString(money),"Sorry you lose",JOptionPane.DEFAULT_OPTION);
}
else if(given==3 && ((lev!=2) && (lev!=6)))
{thr.stop();
count=0;
JOptionPane.showConfirmDialog(null,"Your winning amount :  "+Integer.toString(money),"Sorry you lose",JOptionPane.DEFAULT_OPTION);
}
else if(given==4 && ((lev!=3) && (lev!=7)))
{thr.stop();
count=0;
JOptionPane.showConfirmDialog(null,"Your winning amount :  "+Integer.toString(money),"Sorry you lose",JOptionPane.DEFAULT_OPTION);
}
else
{}
        
        
        g2D.setColor(Color.LIGHT_GRAY);
        g2D.fillOval(100, 100, 220, 70);
         g2D.setColor(Color.green);
       //  g2D.drawOval(100, 100, 220, 70);
         for(int i=0;i<4;i++)
         {
         g2D.drawOval(100-i, 100, 220-20*i, 70);
         }
             
        g2D.setColor(Color.LIGHT_GRAY);
        g2D.fillOval(800, 100, 220, 70);
         g2D.setColor(Color.green);
      
         //g2D.drawOval(800, 100, 220, 70);
         for(int i=0;i<4;i++)
         {
         g2D.drawOval(800+30*i, 100, 220-30*i, 70);
         }
        
         g2D.setColor(Color.LIGHT_GRAY);
         g2D.fillRect(210, 100, 700, 70);
         g2D.setColor(Color.green);
        g2D.fillRect(180, 100, 760, 4);
        g2D.fillRect(190, 167, 740, 4);
        
     /*   **********************************************************************************/
     if(given==1 && ((lev!=0) && (lev!=4) && (lev!=8)))
     {  g2D.setColor(Color.red);
       // JOptionPane.showConfirmDialog(null,"Your winning amount :  "+Integer.toString(money),"Sorry you lose",JOptionPane.DEFAULT_OPTION);
     stop=1;
     }
     
     else
     {g2D.setColor(Color.LIGHT_GRAY);  }
   //     g2D.setColor(Color.LIGHT_GRAY);    
        g2D.fillOval(150, 225, 130, 50);
         g2D.setColor(Color.green);
          for(int i=0;i<4;i++)
         {
         g2D.drawOval(150-i, 225, 130-10*i, 50);
         }
             if(given==1 && ((lev!=0) && (lev!=4) && (lev!=8)))
     {  g2D.setColor(Color.red);}
     else
     {g2D.setColor(Color.LIGHT_GRAY);  }
         //   g2D.setColor(Color.LIGHT_GRAY);
         g2D.fillOval(350, 225, 130, 50);
          g2D.setColor(Color.green);
          for(int i=0;i<4;i++)
         {
         g2D.drawOval(350+15*i, 225, 130-15*i, 50);
         }
     
       if(given==1 && ((lev!=0) && (lev!=4) && (lev!=8)))
     {  g2D.setColor(Color.red);}
     else
     {g2D.setColor(Color.LIGHT_GRAY);  }
           // g2D.setColor(Color.LIGHT_GRAY);
            g2D.fillRect(215, 225, 200, 50);
           g2D.setColor(Color.green);
        g2D.fillRect(190, 225, 250, 4);
        g2D.fillRect(190, 273, 250, 4);
     
         if(given==2 && ((lev!=1) && (lev!=5) && (lev!=9)))
     {  g2D.setColor(Color.red);
    // JOptionPane.showConfirmDialog(null,"Your winning amount :  "+Integer.toString(money),"Sorry you lose",JOptionPane.DEFAULT_OPTION);
     stop=1;
     }
     else
     {g2D.setColor(Color.LIGHT_GRAY);  }
            // g2D.setColor(Color.LIGHT_GRAY);
             g2D.fillOval(650, 225, 130, 50);
             g2D.setColor(Color.green);
          for(int i=0;i<4;i++)
         {
         g2D.drawOval(650-i, 225, 130-10*i, 50);
         }
           if(given==2 && ((lev!=1) && (lev!=5) && (lev!=9)))
     {  g2D.setColor(Color.red);
     }
     else
     {g2D.setColor(Color.LIGHT_GRAY);  }
           // g2D.setColor(Color.LIGHT_GRAY);
         
            g2D.fillOval(850, 225, 130, 50);
            g2D.setColor(Color.green);
          for(int i=0;i<4;i++)
         {
         g2D.drawOval(850+15*i, 225, 130-15*i, 50);
         }
           if(given==2 && ((lev!=1) && (lev!=5) && (lev!=9)))
     {  g2D.setColor(Color.red);}
     else
     {g2D.setColor(Color.LIGHT_GRAY);  }
           // g2D.setColor(Color.LIGHT_GRAY);
        
            g2D.fillRect(715, 225, 200, 50);
             g2D.setColor(Color.green);
        g2D.fillRect(690, 225, 250, 4);
        g2D.fillRect(690, 273, 250, 4);
     
     /*   **********************************************************************************/   
      if(given==3 && ((lev!=2) && (lev!=6)))
     {  g2D.setColor(Color.red);
    // JOptionPane.showConfirmDialog(null,"Your winning amount :  "+Integer.toString(money),"Sorry you lose",JOptionPane.DEFAULT_OPTION);
     stop=1;
     }
     else
     {g2D.setColor(Color.LIGHT_GRAY);  }        
    // g2D.setColor(Color.LIGHT_GRAY);
              g2D.fillOval(150, 325, 130, 50);
             g2D.setColor(Color.green);
          for(int i=0;i<4;i++)
         {
         g2D.drawOval(150-i, 325, 130-10*i, 50);
         }
           if(given==3 && ((lev!=2) && (lev!=6)))
     {  g2D.setColor(Color.red);}
     else
     {g2D.setColor(Color.LIGHT_GRAY);  }
          //  g2D.setColor(Color.LIGHT_GRAY);
     
         g2D.fillOval(350, 325, 130, 50);
         g2D.setColor(Color.green);
          for(int i=0;i<4;i++)
         {
         g2D.drawOval(350+15*i, 325, 130-15*i, 50);
         }
           if(given==3 && ((lev!=2) && (lev!=6)))
     {  g2D.setColor(Color.red);}
     else
     {g2D.setColor(Color.LIGHT_GRAY);  }
           // g2D.setColor(Color.LIGHT_GRAY);
        
         g2D.fillRect(215, 325, 200, 50);
          g2D.setColor(Color.green);
        g2D.fillRect(190, 325, 250, 4);
        g2D.fillRect(190, 373, 250, 4);
    
        
        /* **************************************************************************** */
         if(given==4 && ((lev!=3) && (lev!=7)))
     {  g2D.setColor(Color.red);
    // JOptionPane.showConfirmDialog(null,"Your winning amount :  "+Integer.toString(money),"Sorry you lose",JOptionPane.DEFAULT_OPTION);
     stop=1;
     }
     else
     {g2D.setColor(Color.LIGHT_GRAY);  }
            // g2D.setColor(Color.LIGHT_GRAY);
  
            g2D.fillOval(650, 325, 130, 50);
             g2D.setColor(Color.green);
          for(int i=0;i<4;i++)
         {
         g2D.drawOval(650-i, 325, 130-10*i, 50);
         }
           if(given==4 && ((lev!=3) && (lev!=7)))
     {  g2D.setColor(Color.red);}
     else
     {g2D.setColor(Color.LIGHT_GRAY);  }
            //g2D.setColor(Color.LIGHT_GRAY);
            g2D.fillOval(850, 325, 130, 50);
             g2D.setColor(Color.green);
          for(int i=0;i<4;i++)
         {
         g2D.drawOval(850+15*i, 325, 130-15*i, 50);
         }
           if(given==4 && ((lev!=3) && (lev!=7)))
     {  g2D.setColor(Color.red);}
     else
     {g2D.setColor(Color.LIGHT_GRAY);  }
           // g2D.setColor(Color.LIGHT_GRAY);
            g2D.fillRect(715, 325, 200, 50);
            g2D.setColor(Color.green);
        g2D.fillRect(690, 325, 250, 4);
        g2D.fillRect(690, 373, 250, 4);
    
        
        /* **************************************************************************** */
        
         
        // g2D.drawLine(480,250 , 980,250 );
         g2D.fillRect(480, 249, 167, 2);
         g2D.fillRect(480, 349, 167, 2);
       
       //                       g2D.fillRect(5, 422, 1336, 6);
       
       /* ****************************************************   */
       
       if(stop==1)
       {
       g2D.setColor(Color.green);                                               
       if(lev==0 || lev==4 || lev==8)
       {   g2D.fillOval(150, 225, 130, 50);
g2D.fillOval(350, 225, 130, 50);
   g2D.fillRect(215, 225, 200, 50);}
       else if(lev==1 || lev==5 || lev==9) 
       { g2D.fillOval(650, 225, 130, 50);
g2D.fillOval(850, 225, 130, 50);
g2D.fillRect(715, 225, 200, 50);
}
       else if(lev==2 || lev==6)
       {g2D.fillOval(150, 325, 130, 50); 
g2D.fillOval(350, 325, 130, 50);
 g2D.fillRect(215, 325, 200, 50);
}
       else if(lev==3 || lev==7)
       { g2D.fillOval(650, 325, 130, 50);
 g2D.fillOval(850, 325, 130, 50);
 g2D.fillRect(715, 325, 200, 50);
}
       else
       {}



    }
       
         /* **************************************************************************** */
         if(top1==1)
         {
             g2D.setColor(Color.green);
         g2D.fillOval(150, 225, 130, 50);
g2D.fillOval(350, 225, 130, 50);
   g2D.fillRect(215, 225, 200, 50);
         }
         if(top2==1)
         {
         g2D.fillOval(650, 225, 130, 50);
g2D.fillOval(850, 225, 130, 50);
g2D.fillRect(715, 225, 200, 50);
         }
         if(top3==1)
         {
          g2D.fillOval(150, 325, 130, 50); 
g2D.fillOval(350, 325, 130, 50);
 g2D.fillRect(215, 325, 200, 50);
         }
         if(top4==1)
         {
          g2D.fillOval(650, 325, 130, 50);
 g2D.fillOval(850, 325, 130, 50);
 g2D.fillRect(715, 325, 200, 50);
         }
         
          /* **************************************************************************** */
       level();
       Font c=g2D.getFont();
     Font n=c.deriveFont(c.getSize()*1.7F);
     g2D.setFont(n);
     
       g2D.setColor(Color.black);
     g2D.drawChars(arrq, 0, arrq.length, 180, 144);
   // if right g2D.setColor(Color.BLUE);
    // if wrong g2D.setColor(Color.red);
       g2D.drawChars(arropta, 0, arropta.length, 195, 257);
       g2D.drawChars(arroptb, 0, arroptb.length, 695, 257);
      g2D.drawChars(arroptc, 0, arroptc.length, 195, 357);
       g2D.drawChars(arroptd, 0, arroptd.length, 695, 357);
      
       
       /* ****************************************************   */
       
 /*     if(flag==1)
      {
      g2D.setColor(Color.red);
              g2D.fillOval(150, 225, 130, 50);
g2D.fillOval(350, 225, 130, 50);
   g2D.fillRect(215, 225, 200, 50);
   
      }
       */
 
 
        /* ****************************************************   */
       if(lev==0)
       {
       money=0;
          g2D.setColor(Color.yellow);    
     String a1=new String("Rs 5000");
     char arr1[]=a1.toCharArray();
     g2D.drawChars(arr1, 0, 7, 1160, 400);
     String a2=new String("Rs 20,000");
     char arr2[]=a2.toCharArray();
     g2D.drawChars(arr2, 0, 9, 1160, 380);
      String a3=new String("Rs 80,000");
     char arr3[]=a3.toCharArray();
     g2D.drawChars(arr3, 0, 9, 1160, 360);
     g2D.setColor(Color.white);  
     String a4=new String("Rs 1,60,000");
     char arr4[]=a4.toCharArray();
     g2D.drawChars(arr4, 0, 11, 1160, 340);
     g2D.setColor(Color.yellow);
      String a5=new String("Rs 3,20,000");
     char arr5[]=a5.toCharArray();
     g2D.drawChars(arr5, 0, 11, 1160, 320);
      String a6=new String("Rs 6,40,000");
      char arr6[]=a6.toCharArray();
     g2D.drawChars(arr6, 0, 11, 1160, 300);
        g2D.setColor(Color.white); 
      String a7=new String("Rs 12,50,000");
        char arr7[]=a7.toCharArray();
     g2D.drawChars(arr7, 0, 12, 1160, 280);
        g2D.setColor(Color.yellow);
      String a8=new String("Rs 25 Lakh");
     char arr8[]=a8.toCharArray();
     g2D.drawChars(arr8, 0, 10, 1160, 260);
      String a9=new String("Rs 50 Lakh");
     char arr9[]=a9.toCharArray();
     g2D.drawChars(arr9, 0, 10, 1160, 240);
     g2D.setColor(Color.white);  
      String a10=new String("Rs 1 Crore");
     char arr10[]=a10.toCharArray();
     g2D.drawChars(arr10, 0, 10, 1160, 220);
     
       }
       
       else if(lev==1)
       {
           money=0;
          g2D.setColor(Color.green);    
     String a1=new String("Rs 5000");
     char arr1[]=a1.toCharArray();
     g2D.drawChars(arr1, 0, 7, 1160, 400);
     g2D.setColor(Color.yellow);    
     String a2=new String("Rs 20,000");
     char arr2[]=a2.toCharArray();
     g2D.drawChars(arr2, 0, 9, 1160, 380);
      String a3=new String("Rs 80,000");
     char arr3[]=a3.toCharArray();
     g2D.drawChars(arr3, 0, 9, 1160, 360);
     g2D.setColor(Color.white);  
     String a4=new String("Rs 1,60,000");
     char arr4[]=a4.toCharArray();
     g2D.drawChars(arr4, 0, 11, 1160, 340);
     g2D.setColor(Color.yellow);
      String a5=new String("Rs 3,20,000");
     char arr5[]=a5.toCharArray();
     g2D.drawChars(arr5, 0, 11, 1160, 320);
      String a6=new String("Rs 6,40,000");
     char arr6[]=a6.toCharArray();
     g2D.drawChars(arr6, 0, 11, 1160, 300);
        g2D.setColor(Color.white); 
      String a7=new String("Rs 12,50,000");
     char arr7[]=a7.toCharArray();
     g2D.drawChars(arr7, 0, 12, 1160, 280);
      g2D.setColor(Color.yellow);
      String a8=new String("Rs 25 Lakh");
     char arr8[]=a8.toCharArray();
     g2D.drawChars(arr8, 0, 10, 1160, 260);
      String a9=new String("Rs 50 Lakh");
     char arr9[]=a9.toCharArray();
     g2D.drawChars(arr9, 0, 10, 1160, 240);
     g2D.setColor(Color.white);  
      String a10=new String("Rs 1 Crore");
     char arr10[]=a10.toCharArray();
     g2D.drawChars(arr10, 0, 10, 1160, 220);
     
       }
       else if(lev==2)
       { money=0;
          g2D.setColor(Color.green);    
     String a1=new String("Rs 5000");
     char arr1[]=a1.toCharArray();
     g2D.drawChars(arr1, 0, 7, 1160, 400);
     String a2=new String("Rs 20,000");
     char arr2[]=a2.toCharArray();
     g2D.drawChars(arr2, 0, 9, 1160, 380);
     g2D.setColor(Color.yellow);   
      String a3=new String("Rs 80,000");
     char arr3[]=a3.toCharArray();
     g2D.drawChars(arr3, 0, 9, 1160, 360);
     g2D.setColor(Color.white);  
     String a4=new String("Rs 1,60,000");
     char arr4[]=a4.toCharArray();
     g2D.drawChars(arr4, 0, 11, 1160, 340);
     g2D.setColor(Color.yellow);
      String a5=new String("Rs 3,20,000");
     char arr5[]=a5.toCharArray();
     g2D.drawChars(arr5, 0, 11, 1160, 320);
      String a6=new String("Rs 6,40,000");  
     char arr6[]=a6.toCharArray();
     g2D.drawChars(arr6, 0, 11, 1160, 300);
        g2D.setColor(Color.white); 
      String a7=new String("Rs 12,50,000");
     char arr7[]=a7.toCharArray();
     g2D.drawChars(arr7, 0, 12, 1160, 280);
      g2D.setColor(Color.yellow);
      String a8=new String("Rs 25 Lakh");
     char arr8[]=a8.toCharArray();
     g2D.drawChars(arr8, 0, 10, 1160, 260);
      String a9=new String("Rs 50 Lakh");
     char arr9[]=a9.toCharArray();
     g2D.drawChars(arr9, 0, 10, 1160, 240);
     g2D.setColor(Color.white);  
      String a10=new String("Rs 1 Crore");
     char arr10[]=a10.toCharArray();
     g2D.drawChars(arr10, 0, 10, 1160, 220);
     
       }
       else if(lev==3)
       {money=0;
          g2D.setColor(Color.green);    
     String a1=new String("Rs 5000");
     char arr1[]=a1.toCharArray();
     g2D.drawChars(arr1, 0, 7, 1160, 400);
     String a2=new String("Rs 20,000");
     char arr2[]=a2.toCharArray();
     g2D.drawChars(arr2, 0, 9, 1160, 380);
     String a3=new String("Rs 80,000");
     char arr3[]=a3.toCharArray();
     g2D.drawChars(arr3, 0, 9, 1160, 360);
     g2D.setColor(Color.white);  
     String a4=new String("Rs 1,60,000");
     char arr4[]=a4.toCharArray();
     g2D.drawChars(arr4, 0, 11, 1160, 340);
     g2D.setColor(Color.yellow);
      String a5=new String("Rs 3,20,000");
     char arr5[]=a5.toCharArray();
     g2D.drawChars(arr5, 0, 11, 1160, 320);
      String a6=new String("Rs 6,40,000");
     char arr6[]=a6.toCharArray();
     g2D.drawChars(arr6, 0, 11, 1160, 300);
        g2D.setColor(Color.white); 
      String a7=new String("Rs 12,50,000");
     char arr7[]=a7.toCharArray();
     g2D.drawChars(arr7, 0, 12, 1160, 280);
      g2D.setColor(Color.yellow);
      String a8=new String("Rs 25 Lakh");
     char arr8[]=a8.toCharArray();
     g2D.drawChars(arr8, 0, 10, 1160, 260);
      String a9=new String("Rs 50 Lakh");
     char arr9[]=a9.toCharArray();
     g2D.drawChars(arr9, 0, 10, 1160, 240);
     g2D.setColor(Color.white);  
      String a10=new String("Rs 1 Crore");
     char arr10[]=a10.toCharArray();
     g2D.drawChars(arr10, 0, 10, 1160, 220);
     
          
       }
       else if(lev==4)
       {money=160000;
          g2D.setColor(Color.green);    
     String a1=new String("Rs 5000");
     char arr1[]=a1.toCharArray();
     g2D.drawChars(arr1, 0, 7, 1160, 400);
     String a2=new String("Rs 20,000");
     char arr2[]=a2.toCharArray();
     g2D.drawChars(arr2, 0, 9, 1160, 380);
     String a3=new String("Rs 80,000");
     char arr3[]=a3.toCharArray();
     g2D.drawChars(arr3, 0, 9, 1160, 360);
     g2D.setColor(Color.magenta);  
     String a4=new String("Rs 1,60,000");
     char arr4[]=a4.toCharArray();
     g2D.drawChars(arr4, 0, 11, 1160, 340);
     g2D.setColor(Color.yellow);
      String a5=new String("Rs 3,20,000");
     char arr5[]=a5.toCharArray();
     g2D.drawChars(arr5, 0, 11, 1160, 320);
      String a6=new String("Rs 6,40,000");
     char arr6[]=a6.toCharArray();
     g2D.drawChars(arr6, 0, 11, 1160, 300);
        g2D.setColor(Color.white); 
      String a7=new String("Rs 12,50,000");
     char arr7[]=a7.toCharArray();
     g2D.drawChars(arr7, 0, 12, 1160, 280);
      g2D.setColor(Color.yellow);
      String a8=new String("Rs 25 Lakh");
     char arr8[]=a8.toCharArray();
     g2D.drawChars(arr8, 0, 10, 1160, 260);
      String a9=new String("Rs 50 Lakh");
     char arr9[]=a9.toCharArray();
     g2D.drawChars(arr9, 0, 10, 1160, 240);
     g2D.setColor(Color.white);  
      String a10=new String("Rs 1 Crore");
     char arr10[]=a10.toCharArray();
     g2D.drawChars(arr10, 0, 10, 1160, 220);
      
       }
       else if(lev==5)
       {money=160000;
          g2D.setColor(Color.green);    
     String a1=new String("Rs 5000");
     char arr1[]=a1.toCharArray();
     g2D.drawChars(arr1, 0, 7, 1160, 400);
     String a2=new String("Rs 20,000");
     char arr2[]=a2.toCharArray();
     g2D.drawChars(arr2, 0, 9, 1160, 380);
     String a3=new String("Rs 80,000");
     char arr3[]=a3.toCharArray();
     g2D.drawChars(arr3, 0, 9, 1160, 360);
     g2D.setColor(Color.magenta);  
     String a4=new String("Rs 1,60,000");
     char arr4[]=a4.toCharArray();
     g2D.drawChars(arr4, 0, 11, 1160, 340);
     g2D.setColor(Color.green);
      String a5=new String("Rs 3,20,000");
     char arr5[]=a5.toCharArray();
     g2D.drawChars(arr5, 0, 11, 1160, 320);
       g2D.setColor(Color.yellow);
      String a6=new String("Rs 6,40,000"); 
     char arr6[]=a6.toCharArray();
     g2D.drawChars(arr6, 0, 11, 1160, 300);
        g2D.setColor(Color.white); 
      String a7=new String("Rs 12,50,000");
     char arr7[]=a7.toCharArray();
     g2D.drawChars(arr7, 0, 12, 1160, 280);
      g2D.setColor(Color.yellow);
      String a8=new String("Rs 25 Lakh");
     char arr8[]=a8.toCharArray();
     g2D.drawChars(arr8, 0, 10, 1160, 260);
      String a9=new String("Rs 50 Lakh");
     char arr9[]=a9.toCharArray();
     g2D.drawChars(arr9, 0, 10, 1160, 240);
     g2D.setColor(Color.white);  
      String a10=new String("Rs 1 Crore");
     char arr10[]=a10.toCharArray();
     g2D.drawChars(arr10, 0, 10, 1160, 220);
      
       }
       else if(lev==6)
       {money=160000;
          g2D.setColor(Color.green);    
     String a1=new String("Rs 5000");
     char arr1[]=a1.toCharArray();
     g2D.drawChars(arr1, 0, 7, 1160, 400);
     String a2=new String("Rs 20,000");
     char arr2[]=a2.toCharArray();
     g2D.drawChars(arr2, 0, 9, 1160, 380);
     String a3=new String("Rs 80,000");
     char arr3[]=a3.toCharArray();
     g2D.drawChars(arr3, 0, 9, 1160, 360);
     g2D.setColor(Color.magenta);  
     String a4=new String("Rs 1,60,000");
     char arr4[]=a4.toCharArray();
     g2D.drawChars(arr4, 0, 11, 1160, 340);
     g2D.setColor(Color.green);
      String a5=new String("Rs 3,20,000");
     char arr5[]=a5.toCharArray();
     g2D.drawChars(arr5, 0, 11, 1160, 320);
      String a6=new String("Rs 6,40,000");
     char arr6[]=a6.toCharArray();
     g2D.drawChars(arr6, 0, 11, 1160, 300);
        g2D.setColor(Color.white); 
      String a7=new String("Rs 12,50,000");
     char arr7[]=a7.toCharArray();
     g2D.drawChars(arr7, 0, 12, 1160, 280);
      g2D.setColor(Color.yellow);
      String a8=new String("Rs 25 Lakh");
     char arr8[]=a8.toCharArray();
     g2D.drawChars(arr8, 0, 10, 1160, 260);
      String a9=new String("Rs 50 Lakh");
     char arr9[]=a9.toCharArray();
     g2D.drawChars(arr9, 0, 10, 1160, 240);
     g2D.setColor(Color.white);  
      String a10=new String("Rs 1 Crore");
     char arr10[]=a10.toCharArray();
     g2D.drawChars(arr10, 0, 10, 1160, 220);
      
       }
       else if(lev==7)
       {money=1250000;
          g2D.setColor(Color.green);    
     String a1=new String("Rs 5000");
     char arr1[]=a1.toCharArray();
     g2D.drawChars(arr1, 0, 7, 1160, 400);
     String a2=new String("Rs 20,000");
     char arr2[]=a2.toCharArray();
     g2D.drawChars(arr2, 0, 9, 1160, 380);
     String a3=new String("Rs 80,000");
     char arr3[]=a3.toCharArray();
     g2D.drawChars(arr3, 0, 9, 1160, 360);
     g2D.setColor(Color.white);  
     String a4=new String("Rs 1,60,000");
     char arr4[]=a4.toCharArray();
     g2D.drawChars(arr4, 0, 11, 1160, 340);
     g2D.setColor(Color.green);
      String a5=new String("Rs 3,20,000");
     char arr5[]=a5.toCharArray();
     g2D.drawChars(arr5, 0, 11, 1160, 320);
      String a6=new String("Rs 6,40,000");
     char arr6[]=a6.toCharArray();
     g2D.drawChars(arr6, 0, 11, 1160, 300);
        g2D.setColor(Color.magenta); 
      String a7=new String("Rs 12,50,000");
     char arr7[]=a7.toCharArray();
     g2D.drawChars(arr7, 0, 12, 1160, 280);
      g2D.setColor(Color.yellow);
      String a8=new String("Rs 25 Lakh");
     char arr8[]=a8.toCharArray();
     g2D.drawChars(arr8, 0, 10, 1160, 260);
      String a9=new String("Rs 50 Lakh");
     char arr9[]=a9.toCharArray();
     g2D.drawChars(arr9, 0, 10, 1160, 240);
     g2D.setColor(Color.white);  
      String a10=new String("Rs 1 Crore");
     char arr10[]=a10.toCharArray();
     g2D.drawChars(arr10, 0, 10, 1160, 220);
      
       }
       else if(lev==8)
       {money=1250000;
       g2D.setColor(Color.green);    
    String s="Rs 5000";
      g2D.drawString(s, 1160, 400);
    
    String a2=new String("Rs 20,000");
     char arr2[]=a2.toCharArray();
     g2D.drawChars(arr2, 0, 9, 1160, 380);
     
    //  String a1=new String("Rs 5000");
     //char arr1[]=a1.toCharArray();
     //g2D.drawChars(arr1, 0, 7, 1160, 400);
  //   String t=new String("Rs 20,000");
     
     String a3=new String("Rs 80,000");
     char arr3[]=a3.toCharArray();
     g2D.drawChars(arr3, 0, 9, 1160, 360);
          g2D.setColor(Color.white);  
     String a4=new String("Rs 1,60,000");
     char arr4[]=a4.toCharArray();
     g2D.drawChars(arr4, 0, 11, 1160, 340);
     g2D.setColor(Color.green);
      String a5=new String("Rs 3,20,000");
     char arr5[]=a5.toCharArray();
     g2D.drawChars(arr5, 0, 11, 1160, 320);
      String a6=new String("Rs 6,40,000");
     char arr6[]=a6.toCharArray();
     g2D.drawChars(arr6, 0, 11, 1160, 300);
        g2D.setColor(Color.magenta); 
      String a7=new String("Rs 12,50,000");
     char arr7[]=a7.toCharArray();
     g2D.drawChars(arr7, 0, 12, 1160, 280);
      g2D.setColor(Color.green);
      String a8=new String("Rs 25 Lakh");
     char arr8[]=a8.toCharArray();
     g2D.drawChars(arr8, 0, 10, 1160, 260);
     g2D.setColor(Color.yellow);
      String a9=new String("Rs 50 Lakh");
      char arr9[]=a9.toCharArray();
     g2D.drawChars(arr9, 0, 10, 1160, 240);
    
    
     g2D.setColor(Color.white);  
      String a10=new String("Rs 1 Crore");
     char arr10[]=a10.toCharArray();
     g2D.drawChars(arr10, 0, 10, 1160, 220);
               
       }
       else if(lev==9)
       {money=1250000;  
         g2D.setColor(Color.green); 
           String a1=new String("Rs 5000");
     char arr1[]=a1.toCharArray();
     g2D.drawChars(arr1, 0, 7, 1160, 400);
     String a2=new String("Rs 20,000");
     char arr2[]=a2.toCharArray();
     g2D.drawChars(arr2, 0, 9, 1160, 380);
     
     String a3=new String("Rs 80,000");
     char arr3[]=a3.toCharArray();
     g2D.drawChars(arr3, 0, 9, 1160, 360);
     g2D.setColor(Color.white);  
     String a4=new String("Rs 1,60,000");
     char arr4[]=a4.toCharArray();
     g2D.drawChars(arr4, 0, 11, 1160, 340);
     g2D.setColor(Color.green);
      String a5=new String("Rs 3,20,000");
     char arr5[]=a5.toCharArray();
     g2D.drawChars(arr5, 0, 11, 1160, 320);
      String a6=new String("Rs 6,40,000");
     char arr6[]=a6.toCharArray();
     g2D.drawChars(arr6, 0, 11, 1160, 300);
        g2D.setColor(Color.magenta); 
      String a7=new String("Rs 12,50,000");
     char arr7[]=a7.toCharArray();
     g2D.drawChars(arr7, 0, 12, 1160, 280);
      g2D.setColor(Color.green);
      String a8=new String("Rs 25 Lakh");
     char arr8[]=a8.toCharArray();
     g2D.drawChars(arr8, 0, 10, 1160, 260);      
      String a9=new String("Rs 50 Lakh");
     char arr9[]=a9.toCharArray();
     g2D.drawChars(arr9, 0, 10, 1160, 240);
     g2D.setColor(Color.white);  
      String a10=new String("Rs 1 Crore");
     char arr10[]=a10.toCharArray();
     g2D.drawChars(arr10, 0, 10, 1160, 220);
               
       }
       else
       {
       }
       
       if(lev==9 && stop==1)
       {
              g2D.setColor(Color.green);    
    String a1=new String("Rs 5000");
     char arr1[]=a1.toCharArray();
     g2D.drawChars(arr1, 0, 7, 1160, 400);
     String a2=new String("Rs 20,000");
     char arr2[]=a2.toCharArray();
     g2D.drawChars(arr2, 0, 9, 1160, 380);
    
     String a3=new String("Rs 80,000");
     char arr3[]=a3.toCharArray();
     g2D.drawChars(arr3, 0, 9, 1160, 360);
     g2D.setColor(Color.white);  
     String a4=new String("Rs 1,60,000");
     char arr4[]=a4.toCharArray();
     g2D.drawChars(arr4, 0, 11, 1160, 340);
     g2D.setColor(Color.green);
      String a5=new String("Rs 3,20,000");
     char arr5[]=a5.toCharArray();
     g2D.drawChars(arr5, 0, 11, 1160, 320);
      String a6=new String("Rs 6,40,000");
     char arr6[]=a6.toCharArray();
     g2D.drawChars(arr6, 0, 11, 1160, 300);
        g2D.setColor(Color.white); 
      String a7=new String("Rs 12,50,000");
     char arr7[]=a7.toCharArray();
     g2D.drawChars(arr7, 0, 12, 1160, 280);
      g2D.setColor(Color.green);
      String a8=new String("Rs 25 Lakh");
     char arr8[]=a8.toCharArray();
     g2D.drawChars(arr8, 0, 10, 1160, 260);
      String a9=new String("Rs 50 Lakh");
     char arr9[]=a9.toCharArray();
     g2D.drawChars(arr9, 0, 10, 1160, 240);
     g2D.setColor(Color.magenta);  
      String a10=new String("Rs 1 Crore");
     char arr10[]=a10.toCharArray();
     g2D.drawChars(arr10, 0, 10, 1160, 220);
       }
       
       
        
     g2D.setColor(Color.ORANGE);
  char ch[]={'*'};
   if(direction==1)
     {
     ch[0]='d';
     }
     else if(direction==4)
     {
     ch[0]='a';
     }
     else if(direction==3)
     {
     ch[0]='b';
     }
     else
     {
     ch[0]='c';
     }
   
  for(int i=0;i<5;i++)
  {
  g2D.drawChars(ch, 0, 1, px[i], py[i]);
     //  g2D.drawChars(ch, 0, 1, 100, 100);
  }    
  
 cout=String.valueOf(count);
 g2D.drawString(cout, 1060, 400);

/* ***************************************************    */
  if(top1==1)
  { 
      for(long i=0;i<30000000;i++);
       //  for(long i=0;i<1000000000;i++);
         top1=0;
     lev=lev+1;
         
  }
   if(top2==1)
  {
      for(long i=0;i<30000000;i++);
      //   for(long i=0;i<1000000000;i++);
           top2=0;
     lev=lev+1;
  }
   if(top3==1)
  {
      for(long i=0;i<30000000;i++);
        // for(long i=0;i<1000000000;i++);
         top3=0;
     lev=lev+1;
  }
   if(top4==1)
  {
      for(long i=0;i<30000000;i++);
    //       for(long i=0;i<1000000000;i++);
           top4=0;
     lev=lev+1;
  }
 /* ***************************************************    */ 
        }
        
        public static void main(String args[])
        {
        
                     ImagePanel my_Game=new ImagePanel();
        JFrame myFrame=new JFrame(" Simple Snake Game ");
        myFrame.setSize(1365,725);
        myFrame.getContentPane().add(my_Game);
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.addKeyListener(my_Game);
         my_Game.init();
      //  my_Game.start();
       // myFrame.getContentPane().setBackground(Color.yellow);
      // JPanel p1=snakePanel.getP();
        my_Game.setVisible(true);
        myFrame.setVisible(true);
       
  
        }
        
        
        public void move()
        {
            if(px[0]<=40)
            {   count=30;
                given=1;
                direction=2;
             if(lev==0 || lev==4 || lev==8)
             {
   //               lev=lev+1;
                  given=-1;
                  flag=1;
                  top1=1;
 
             }
             else
             {
                
             }
                hx=380;
                hy=560;
                for(int i=0;i<5;i++)
                {
                px[i]=400+20*i;
                py[i]=560;
                }
             
            }
            else if(py[0]>=650)
            {
                count=30;
                 given=2;
                 direction=2;
                 if(lev==1 || lev==5)
                {
 //                lev=lev+1;
                 given=-1;
                  flag=2;
                  top2=1;
                 }
                 else if(lev==9)
                 {
                     stop=1;
                     money=10000000;
                     repaint();
                     JOptionPane.showConfirmDialog(null,"You won the game.\nYour winning amount :  "+Integer.toString(money),"Congratulations...",JOptionPane.DEFAULT_OPTION);
                 }
                 else
                 {
                 
                 }
            
            hx=280;
                hy=500;
                for(int i=0;i<5;i++)
                {
                px[i]=300+20*i;
                py[i]=500;
                }
             
            }
            else if(px[0]>=1320)
            {
                count=30;
                 given=3;
                 direction=2;
                 if(lev==2 || lev==6)
                {
                   // lev=lev+1;
                    given=-1;
                     flag=3;
                     top3=1;
                }
                 else
                 {
                 
                 }
            
               hx=280;
                hy=560;
                for(int i=0;i<5;i++)
                {
                px[i]=300+20*i;
                py[i]=560;
                }
             
            }
            else if(py[0]<=473)
            {
                count=30;
                 given=4;
                 direction=2;
                 if(lev==3 || lev==7)
                {
//                    lev=lev+1;
                    given=-1;
                     flag=4;
                     top4=1;
                }
                 else
                 {
                 
                 }
                hx=280;
                hy=600;
                for(int i=0;i<5;i++)
                {
                px[i]=300+20*i;
                py[i]=600;
                }
             
            }
            else
            {}
            
            switch(direction)
            {
            case 1:    if(direction!=3)
                            {
                                hy=py[0]-20;
                      direction=1;
                            }
                    else 
                     {
                       
                     }
            Move_snake();
                       break;//UP
                       
            case 2:   if(direction!=4)   
                       {
                           hx=px[0]+20;
                     direction=2; 
                            }
                      else
                    {
                        
                     }
            Move_snake();
                    break;//RIGHT
            case 3:    
                      if(direction!=1)
                      {
                          hy=py[0]+20;
                      direction=3;
                      }
                      else
                      {}
                      Move_snake();
                     break;//DOWN
                                  
            case 4:   
                       if(direction!=2)
                       {
                           hx=px[0]-20;
                        direction=4; 
                       }
                      else
                       {}
                       
                     Move_snake();
                      break;//LEFT
        } 
               // move();
               
        }
        
        
        
        public   void Move_snake() {
            for(int i=0;i<4;i++) {
                px[4-i]=px[3-i];
                py[4-i]=py[3-i];
                }
                px[0]=hx;
                py[0]=hy;
                repaint();
                        
    }

    
        
    @Override
    public void keyTyped(KeyEvent e) {
        System.out.println("Key typed");
         
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println("Key pressed");
         if(e.getKeyCode()==UP) {
           System.out.println("up");
          // lev=lev+1;
           direction=1;
        } else if (e.getKeyCode()==RIGHT) {
           System.out.println(" righgt");
           direction=2;
        } else if(e.getKeyCode()==DOWN) {
           System.out.println(" sown");
           direction=3;
        } else if(e.getKeyCode()==LEFT) {
            System.out.println("lefgt");
            direction=4;
        }
         if(stop==0)
         {
        move();
         }
         
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    @Override
    public void keyReleased(KeyEvent e) {
       // System.out.println("Key released");
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    class MY_Thread extends Thread {
        public   void run() {
            while(stop!=1) {
               // my_engin.Move_mySnake(direction,false);
                try {
                    Thread.sleep(500);
                    move();
                    Thread.sleep(500);
                    move();
                    count=count-1;
                    repaint(1050,380,100,100);
                            if(count<=0)
                            {
                            JOptionPane.showConfirmDialog(null,"Sorry you lose\nYour winning amount :  "+Integer.toString(money),"  Time Up !",JOptionPane.DEFAULT_OPTION);
                            stop=1; 
                            repaint();
                            thr.stop();
                            }
                    } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
              //  repaint();
        //        if(my_engin.get_Game_over()) {
          //          stop();
                }
            }
        }
    }
    
    

