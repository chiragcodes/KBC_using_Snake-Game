/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temo;

/**
 *
 * @author Dell
 */
import javax.swing.JApplet;
import java.awt.*; 
import java.net.*;
import javax.imageio.*;
import java.io.*;
import java.awt.Graphics2D;
import java.awt.image.*;


public class BusinessCard extends JApplet
{


    public void paint(Graphics page)
    {
        //Variables used in rectangle
        int x = 0;
        int y = 0;
        int width = 500;
        int height = 300;

        page.drawRect(x, y, width, height);  //draws the rectangle using variables

        //Displays name
        Font f = new Font("Helvetica", Font.BOLD, 26);
        page.setFont(f);
        page.drawString ("anon", 300,100);

        //Displays company
        Font g = new Font("Helvetica", Font.PLAIN, 18);
        page.setFont(g);
       page.drawString ("anon", 320, 120);

        //Displays email
        Font h = new Font("serif", Font.ITALIC, 15);
        page.setFont(h);
        page.drawString ("email", 320,140);

        //int for the logo
        final int MID = 350;
        final int TOP = 168;

        page.setColor (Color.orange);
        page.fillOval (MID, TOP, 60, 60); //bottom half of the trophy. the rounded part.
        page.drawArc (MID-8, TOP+15, 25, 25, 100, 160); //left arc
        page.drawArc (MID+43, TOP+15 , 25, 25, 280, 160); //right arc
        page.fillRect (MID+1, TOP+1, 59, 25); //make the top of the trophy flat basically
        page.fillRect (MID+22, TOP+60, 15, 25); //neck of the trophy
        page.drawLine (MID+48, TOP+84, MID+10, TOP+84); //base of the trophy

        page.setColor (Color.blue);
        Font i = new Font("serif", Font.BOLD, 20); 
        page.setFont(i);
        page.drawString ("#1", MID+20, TOP+30); //Creates the "#1" on the trophy.


        //The following is all code for inserting my image


          BufferedImage photo = null;

        try {
            URL u = new URL(getCodeBase(), "sheri.jpg");
            photo = ImageIO.read(u);
        }   catch (IOException e) {
            page.drawString("Problem reading the file", 100, 100);
        }

        page.drawImage(photo, 10, 10, 150, 225, null);




    }


}