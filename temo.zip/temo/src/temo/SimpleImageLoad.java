/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temo;

/**
 *
 * @author Dell
 */
import java.awt.*;
import java.applet.*;
public class SimpleImageLoad extends Applet
{
Image img;
@Override
public void init() {
img = getImage(getDocumentBase(), getParameter("img"));
}
@Override
public void paint(Graphics g) {
g.drawImage(img, 0, 0, this);
}
}