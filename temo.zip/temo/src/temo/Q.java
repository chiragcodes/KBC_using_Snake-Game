/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temo;

/**
 *
 * @author Dell
 */
public class Q {
    
    String q[]=new String[10];
    String opta[]=new String[10];
    String optb[]=new String[10];
    String optc[]=new String[10];
    String optd[]=new String[10];
    char ans[]=new char[10];
   Q()
   {
   q[0]="Which is a five credit subject ?";
   q[1]="Who is the father of the nation ?";
   q[2]="Who is called our mother ?";
   q[3]="Which is our national animal ?";
   q[4]="When we got independence ?";
   q[5]="Which is our national bird ?";
   q[6]="Which branch is at top now ?";
   q[7]="What is the capital of India ?";
   q[8]="Where is Ahmedabad ?";
   q[9]="Where is Gujarat ?";
   
   opta[0]="a.  OOP";
   opta[1]="a.  Jawaharlal Nehru";
   opta[2]="a.  Indira Gandhi";
   opta[3]="a.  Lion";
   opta[4]="a.  1947";
   opta[5]="a.  Sparrow";
   opta[6]="a.  E.C.";
   opta[7]="a.  Gujarat";
   opta[8]="a.  Gujarat";
   opta[9]="a.  America";
   
   optb[0]="b.  BE";
   optb[1]="b.  Mahatma Gandhi";
   optb[2]="b.  Mamta";
   optb[3]="b.  Dog";
   optb[4]="b.  1948";
   optb[5]="b.  Peacock";
   optb[6]="b.  M.E.";
   optb[7]="b.  TamilNadu";
   optb[8]="b.  Maharashtra";
   optb[9]="b.  India";
   
   
   ans[0]='a';
   ans[1]='b';
   ans[2]='c';
   ans[3]='d';
   ans[4]='a';
   ans[5]='b';
   ans[6]='c';
   ans[7]='d';
   ans[8]='a';
   ans[9]='b';
   
   optc[0]="c.  AM";
   optc[1]="c.  Sardar patel";
   optc[2]="c.  Cow";
   optc[3]="c.  Elephant";
   optc[4]="c.  1949";
   optc[5]="c.  Owl";
   optc[6]="c.  C.E.";
   optc[7]="c.  Kerala";
   optc[8]="c.  M.P.";
   optc[9]="c.  China";
   
   optd[0]="d.  MFCS";
   optd[1]="d.  Modi";
   optd[2]="d.  None";
   optd[3]="d.  Tiger";
   optd[4]="d.  1950";
   optd[5]="d.  Parrot";
   optd[6]="d.  Civil";
   optd[7]="d.  Delhi";
   optd[8]="d.  Kerala";
   optd[9]="d.  Japan";
   
   }
    
   String getq(int i)
   {
   return q[i];
   }
   
    String getopa(int i)
    {
    return opta[i];
    }
    
    String getopb(int i)
    {
    return optb[i];
    }
    
    String getopc(int i)
    {
    return optc[i];
    }
    
    String getopd(int i)
    {
    return optd[i];
    }
    
    char getan(int i)
    {
    return ans[i];
    }


}
