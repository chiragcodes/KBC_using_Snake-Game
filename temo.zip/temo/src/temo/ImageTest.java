/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temo;
import java.applet.Applet;
import java.awt.*;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JLabel;


public class ImageTest extends Applet
{
private Image img;


public void init()
{
img = null;
}
public void loadImage()
{
try
{
//img = getImage(getCodeBase(), "welcome.png");
     URL imageURL = this.getClass().getResource("sheri.jpg");
        Image image=Toolkit.getDefaultToolkit().createImage(imageURL);
       Image scaled = image.getScaledInstance(100, 150, Image.SCALE_SMOOTH);
       JLabel label = new JLabel(new ImageIcon(scaled));
       label.setVisible(true);
}
catch(Exception e) { }
}
public void paint(Graphics g)
{
//if (img == null)
loadImage();
g.drawImage(img, 0, 0, this);
}
}